These are the source files for the project : https://www.freelancer.com/projects/Graphic-Design/Horizontal-Twitter-Scroll-Script-HTML/

The images use the unitegallery jquery plugin, which is included and can work with any web page, or systems including wordpress
the proxy php script is included, but not needed for install, as there is a copy going on in another server which can be used.
However if you do not want to use the other server,and wish to not depend on it, then keep the php file and change the url on line 119 in twitterbar.js

The example index page twitter bar is currently pulling from foxnews and 6 most current tweets
    to change twitter account set javascript variable twitter_screen_name, and to set
    the number of tweets to show ,set max_tweets to the number you wish

The JavaScript Instagram example is currently pulling from spacex and using 9 images. Click for larger image and caption.
    To change to (4x4) change width of this element as shown in comments and set instagram_limit to 16
    To change account to pull pictures from set javascript variable instagram_account

This code can be dropped into any website, or content framework, and should work
